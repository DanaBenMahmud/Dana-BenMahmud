package com.example.safebankapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class OrdersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders); // لازم يكون عندك ملف layout باسم activity_orders.xml
    }
}