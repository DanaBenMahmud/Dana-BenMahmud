package com.example.biggernumberapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btnLeft, btnRight;
    TextView scoreText;
    int score = 0;
    int numberLeft, numberRight;
    Random random;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLeft = findViewById(R.id.btnLeft);
        btnRight = findViewById(R.id.btnRight);
        scoreText = findViewById(R.id.scoreText);
        random = new Random();

        generateNumbers();

        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (numberLeft > numberRight) {
                    score++;
                    Toast.makeText(MainActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
                } else {
                    score--;
                    Toast.makeText(MainActivity.this, "Incorrect!", Toast.LENGTH_SHORT).show();
                }
                updateScore();
                generateNumbers();
            }
        });

        btnRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (numberRight > numberLeft) {
                    score++;
                    Toast.makeText(MainActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
                } else {
                    score--;
                    Toast.makeText(MainActivity.this, "Incorrect!", Toast.LENGTH_SHORT).show();
                }
                updateScore();
                generateNumbers();
            }
        });
    }

    private void generateNumbers() {
        numberLeft = random.nextInt(100);
        numberRight = random.nextInt(100);
        while (numberLeft == numberRight) {
            numberRight = random.nextInt(100);
        }
        btnLeft.setText(String.valueOf(numberLeft));
        btnRight.setText(String.valueOf(numberRight));
    }

    private void updateScore() {
        scoreText.setText("Points: " + score);
    }
}