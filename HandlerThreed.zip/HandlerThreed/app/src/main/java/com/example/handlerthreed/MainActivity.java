package com.example.handlerthreed;

import java.util.Random;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    ProgressBar bar1, bar2;
    TextView msgWorking, msgReturned;
    boolean isRunning = false;
    final int MAX_SEC = 60;
    String strTest = "Global value shared among threads";
    int intTest = 0;

    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            String returnedValue = (String) msg.obj;
            msgReturned.setText("🔹 Background Result:\n\n" + returnedValue);
            bar1.incrementProgressBy(2);

            if (bar1.getProgress() == MAX_SEC) {
                msgReturned.setText("✅ Completed - Background thread has stopped");
                isRunning = false;
            }

            if (bar1.getProgress() == bar1.getMax()) {
                msgWorking.setText("🎉 Finished");
                bar1.setVisibility(View.INVISIBLE);
                bar2.setVisibility(View.INVISIBLE);
            } else {
                msgWorking.setText("Processing... " + bar1.getProgress());
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bar1 = findViewById(R.id.progress);
        bar2 = findViewById(R.id.progress2);
        msgWorking = findViewById(R.id.TextView01);
        msgReturned = findViewById(R.id.TextView02);

        bar1.setMax(MAX_SEC);
        bar1.setProgress(0);

        strTest += "-01";
        intTest = 1;
    }

    @Override
    protected void onStart() {
        super.onStart();
        isRunning = true;

        Thread background = new Thread(new Runnable() {
            public void run() {
                try {
                    for (int i = 0; i < MAX_SEC && isRunning; i++) {
                        Thread.sleep(1000);
                        Random rnd = new Random();
                        String data = "🔹 Thread Value: " + rnd.nextInt(101);
                        data += "\n" + strTest + " " + intTest;
                        intTest++;

                        Message msg = handler.obtainMessage(1, data);
                        if (isRunning) {
                            handler.sendMessage(msg);
                        }
                    }
                } catch (Throwable t) {
                    // log error if needed
                }
            }
        });

        background.start();
    }

    @Override
    protected void onStop() {
        super.onStop();
        isRunning = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isRunning = false;
    }
}
