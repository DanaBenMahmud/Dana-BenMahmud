package com.example.handler;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // UI Components
    private ProgressBar myBar;
    private TextView lblTopCaption;
    private EditText txtBox1;
    private Button btnDoSomething;

    private Handler myHandler = new Handler();

    private int accum = 0;
    private long startingMillis;
    private final String PATIENCE_MSG = "Some important data is being collected now.\nPlease be patient.";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblTopCaption = findViewById(R.id.lblTopCaption);
        myBar = findViewById(R.id.myBar);
        txtBox1 = findViewById(R.id.txtBox1);
        btnDoSomething = findViewById(R.id.btnDoSomething);

        myBar.setMax(100);
        myBar.setProgress(0);

        txtBox1.setHint("Foreground distraction. Enter some data here");

        btnDoSomething.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = txtBox1.getText().toString();
                Toast.makeText(MainActivity.this, "You said >> " + inputText, Toast.LENGTH_LONG).show();
            }
        });

        startingMillis = System.currentTimeMillis();
    }

    @Override
    protected void onStart() {
        super.onStart();
        accum = 0;
        myBar.setProgress(0);

        Thread backgroundThread = new Thread(backgroundTask, "BackgroundThread");
        backgroundThread.start();
    }

    private Runnable foregroundTask = new Runnable() {
        @Override
        public void run() {
            try {
                int progressStep = 5;

                long secondsElapsed = (System.currentTimeMillis() - startingMillis) / 1000;
                lblTopCaption.setText(PATIENCE_MSG + "\nTotal sec so far: " + secondsElapsed);

                accum += progressStep;
                myBar.setProgress(accum);

                if (accum >= myBar.getMax()) {
                    lblTopCaption.setText("Background work is OVER!");
                    myBar.setVisibility(View.INVISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Runnable backgroundTask = new Runnable() {
        @Override
        public void run() {
            try {
                for (int i = 0; i < 20; i++) {
                    Thread.sleep(1000);

                    myHandler.post(foregroundTask);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    };
}
